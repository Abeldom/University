// Domokos Abel
// 411

#include "damm0338_L8_2a.h"

int main()
{
    Tomeg_d y(6, 3, 2);
    y.kiir_d();
    cout << y.ossz_dram() << " dram\n";
    cout << 1.77 * y.ossz_dram() << " g\n";
    Tomeg_g x;
    x = y;
    x.kiir_g();

    return 0;
}