#ifndef DAMM338_L2_1_A_H_INCLUDED
#define DAMM338_L2_1_A_H_INCLUDED

void init(double, double);
void felsz();
void duplaz();
void kiir();

#endif