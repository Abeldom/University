#ifndef NEVTER_H_INCLUDED
#define NEVTER_H_INCLUDED

namespace intervallum {
void init(double, double);
void felsz();
void duplaz();
void kiir();
}  // namespace intervallum

#endif